﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FPemesanan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FPemesanan))
        Me.Tjenis = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Ttelpon = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Tno_polisi = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Tcari = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.DGpemesanan = New System.Windows.Forms.DataGridView()
        Me.Btutup = New System.Windows.Forms.Button()
        Me.Bbatal = New System.Windows.Forms.Button()
        Me.Bsimpan = New System.Windows.Forms.Button()
        Me.Tnama_kasir = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Tkode_pemesanan = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Tbahan_bakar = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Twarna = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Tmerk = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Ckode_mobil = New System.Windows.Forms.ComboBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Ttgl_transaksi = New System.Windows.Forms.DateTimePicker()
        Me.Ttgl_berangkat = New System.Windows.Forms.DateTimePicker()
        Me.Ckode_tiket = New System.Windows.Forms.ComboBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Tjumlah_beli = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Tjumlah_bus = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Tharga = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Tkelas = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Tjurusan = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Tsisa = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Tdibayar = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Ttotal_bayar = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Tno_bangku = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Tnm_pembeli = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Tjam_berangkat = New System.Windows.Forms.DateTimePicker()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.DGpemesanan, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'Tjenis
        '
        Me.Tjenis.Location = New System.Drawing.Point(98, 71)
        Me.Tjenis.Name = "Tjenis"
        Me.Tjenis.ReadOnly = True
        Me.Tjenis.Size = New System.Drawing.Size(161, 20)
        Me.Tjenis.TabIndex = 116
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(8, 71)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(37, 17)
        Me.Label8.TabIndex = 115
        Me.Label8.Text = "Jenis"
        '
        'Ttelpon
        '
        Me.Ttelpon.Location = New System.Drawing.Point(128, 47)
        Me.Ttelpon.Name = "Ttelpon"
        Me.Ttelpon.Size = New System.Drawing.Size(161, 20)
        Me.Ttelpon.TabIndex = 114
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(11, 45)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(55, 17)
        Me.Label9.TabIndex = 113
        Me.Label9.Text = "Telepon"
        '
        'Tno_polisi
        '
        Me.Tno_polisi.Location = New System.Drawing.Point(98, 45)
        Me.Tno_polisi.Name = "Tno_polisi"
        Me.Tno_polisi.ReadOnly = True
        Me.Tno_polisi.Size = New System.Drawing.Size(161, 20)
        Me.Tno_polisi.TabIndex = 112
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(8, 45)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(61, 17)
        Me.Label6.TabIndex = 111
        Me.Label6.Text = "No Polisi"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(8, 19)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(42, 17)
        Me.Label7.TabIndex = 109
        Me.Label7.Text = "Mobil"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(18, 413)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(67, 17)
        Me.Label2.TabIndex = 108
        Me.Label2.Text = "Pencarian"
        '
        'Tcari
        '
        Me.Tcari.Location = New System.Drawing.Point(141, 413)
        Me.Tcari.Name = "Tcari"
        Me.Tcari.Size = New System.Drawing.Size(725, 20)
        Me.Tcari.TabIndex = 107
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI Semibold", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(16, 12)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(173, 30)
        Me.Label5.TabIndex = 105
        Me.Label5.Text = "Pemesanan Tiket"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI Semibold", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(16, 25)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(850, 30)
        Me.Label3.TabIndex = 106
        Me.Label3.Text = "_________________________________________________________________________________" & _
            "____________"
        '
        'DGpemesanan
        '
        Me.DGpemesanan.AllowUserToAddRows = False
        Me.DGpemesanan.AllowUserToDeleteRows = False
        Me.DGpemesanan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGpemesanan.Location = New System.Drawing.Point(21, 439)
        Me.DGpemesanan.Name = "DGpemesanan"
        Me.DGpemesanan.ReadOnly = True
        Me.DGpemesanan.Size = New System.Drawing.Size(845, 128)
        Me.DGpemesanan.TabIndex = 103
        '
        'Btutup
        '
        Me.Btutup.BackColor = System.Drawing.Color.RoyalBlue
        Me.Btutup.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.Btutup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btutup.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btutup.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Btutup.Location = New System.Drawing.Point(480, 371)
        Me.Btutup.Name = "Btutup"
        Me.Btutup.Size = New System.Drawing.Size(86, 27)
        Me.Btutup.TabIndex = 102
        Me.Btutup.Text = "Tutup"
        Me.Btutup.UseVisualStyleBackColor = False
        '
        'Bbatal
        '
        Me.Bbatal.BackColor = System.Drawing.Color.RoyalBlue
        Me.Bbatal.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.Bbatal.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Bbatal.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bbatal.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Bbatal.Location = New System.Drawing.Point(607, 371)
        Me.Bbatal.Name = "Bbatal"
        Me.Bbatal.Size = New System.Drawing.Size(86, 27)
        Me.Bbatal.TabIndex = 101
        Me.Bbatal.Text = "Batal"
        Me.Bbatal.UseVisualStyleBackColor = False
        '
        'Bsimpan
        '
        Me.Bsimpan.BackColor = System.Drawing.Color.RoyalBlue
        Me.Bsimpan.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.Bsimpan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Bsimpan.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bsimpan.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Bsimpan.Location = New System.Drawing.Point(725, 371)
        Me.Bsimpan.Name = "Bsimpan"
        Me.Bsimpan.Size = New System.Drawing.Size(141, 27)
        Me.Bsimpan.TabIndex = 99
        Me.Bsimpan.Text = "Simpan/Cetak"
        Me.Bsimpan.UseVisualStyleBackColor = False
        '
        'Tnama_kasir
        '
        Me.Tnama_kasir.Location = New System.Drawing.Point(396, 66)
        Me.Tnama_kasir.Name = "Tnama_kasir"
        Me.Tnama_kasir.ReadOnly = True
        Me.Tnama_kasir.Size = New System.Drawing.Size(193, 20)
        Me.Tnama_kasir.TabIndex = 98
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(289, 66)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(77, 17)
        Me.Label1.TabIndex = 97
        Me.Label1.Text = "Nama Kasir"
        '
        'Tkode_pemesanan
        '
        Me.Tkode_pemesanan.Location = New System.Drawing.Point(126, 66)
        Me.Tkode_pemesanan.Name = "Tkode_pemesanan"
        Me.Tkode_pemesanan.ReadOnly = True
        Me.Tkode_pemesanan.Size = New System.Drawing.Size(129, 20)
        Me.Tkode_pemesanan.TabIndex = 96
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(19, 66)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(59, 17)
        Me.Label4.TabIndex = 95
        Me.Label4.Text = "No Tiket"
        '
        'Tbahan_bakar
        '
        Me.Tbahan_bakar.Location = New System.Drawing.Point(98, 149)
        Me.Tbahan_bakar.Name = "Tbahan_bakar"
        Me.Tbahan_bakar.ReadOnly = True
        Me.Tbahan_bakar.Size = New System.Drawing.Size(161, 20)
        Me.Tbahan_bakar.TabIndex = 123
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(8, 149)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(84, 17)
        Me.Label11.TabIndex = 122
        Me.Label11.Text = "Bahan Bakar"
        '
        'Twarna
        '
        Me.Twarna.Location = New System.Drawing.Point(98, 123)
        Me.Twarna.Name = "Twarna"
        Me.Twarna.ReadOnly = True
        Me.Twarna.Size = New System.Drawing.Size(161, 20)
        Me.Twarna.TabIndex = 121
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.White
        Me.Label12.Location = New System.Drawing.Point(8, 123)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(47, 17)
        Me.Label12.TabIndex = 120
        Me.Label12.Text = "Warna"
        '
        'Tmerk
        '
        Me.Tmerk.Location = New System.Drawing.Point(98, 97)
        Me.Tmerk.Name = "Tmerk"
        Me.Tmerk.ReadOnly = True
        Me.Tmerk.Size = New System.Drawing.Size(161, 20)
        Me.Tmerk.TabIndex = 119
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.White
        Me.Label13.Location = New System.Drawing.Point(8, 97)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(39, 17)
        Me.Label13.TabIndex = 118
        Me.Label13.Text = "Merk"
        '
        'Ckode_mobil
        '
        Me.Ckode_mobil.FormattingEnabled = True
        Me.Ckode_mobil.Location = New System.Drawing.Point(98, 19)
        Me.Ckode_mobil.Name = "Ckode_mobil"
        Me.Ckode_mobil.Size = New System.Drawing.Size(161, 21)
        Me.Ckode_mobil.TabIndex = 124
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.White
        Me.Label14.Location = New System.Drawing.Point(11, 97)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(91, 17)
        Me.Label14.TabIndex = 127
        Me.Label14.Text = "Tgl Berangkat"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.White
        Me.Label15.Location = New System.Drawing.Point(11, 71)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(84, 17)
        Me.Label15.TabIndex = 125
        Me.Label15.Text = "Tgl Transaksi"
        '
        'Ttgl_transaksi
        '
        Me.Ttgl_transaksi.CustomFormat = "dd-MM-yyyy"
        Me.Ttgl_transaksi.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Ttgl_transaksi.Location = New System.Drawing.Point(128, 73)
        Me.Ttgl_transaksi.Name = "Ttgl_transaksi"
        Me.Ttgl_transaksi.Size = New System.Drawing.Size(161, 20)
        Me.Ttgl_transaksi.TabIndex = 128
        '
        'Ttgl_berangkat
        '
        Me.Ttgl_berangkat.CustomFormat = "dd-MM-yyyy"
        Me.Ttgl_berangkat.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Ttgl_berangkat.Location = New System.Drawing.Point(128, 99)
        Me.Ttgl_berangkat.Name = "Ttgl_berangkat"
        Me.Ttgl_berangkat.Size = New System.Drawing.Size(161, 20)
        Me.Ttgl_berangkat.TabIndex = 129
        '
        'Ckode_tiket
        '
        Me.Ckode_tiket.FormattingEnabled = True
        Me.Ckode_tiket.Location = New System.Drawing.Point(94, 17)
        Me.Ckode_tiket.Name = "Ckode_tiket"
        Me.Ckode_tiket.Size = New System.Drawing.Size(175, 21)
        Me.Ckode_tiket.TabIndex = 133
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(11, 123)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(98, 17)
        Me.Label16.TabIndex = 131
        Me.Label16.Text = "Jam Berangkat"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.White
        Me.Label17.Location = New System.Drawing.Point(9, 19)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(37, 17)
        Me.Label17.TabIndex = 130
        Me.Label17.Text = "Tiket"
        '
        'Tjumlah_beli
        '
        Me.Tjumlah_beli.Location = New System.Drawing.Point(94, 149)
        Me.Tjumlah_beli.Name = "Tjumlah_beli"
        Me.Tjumlah_beli.Size = New System.Drawing.Size(175, 20)
        Me.Tjumlah_beli.TabIndex = 143
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.White
        Me.Label18.Location = New System.Drawing.Point(9, 151)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(76, 17)
        Me.Label18.TabIndex = 142
        Me.Label18.Text = "Jumlah Beli"
        '
        'Tjumlah_bus
        '
        Me.Tjumlah_bus.Location = New System.Drawing.Point(94, 123)
        Me.Tjumlah_bus.Name = "Tjumlah_bus"
        Me.Tjumlah_bus.ReadOnly = True
        Me.Tjumlah_bus.Size = New System.Drawing.Size(175, 20)
        Me.Tjumlah_bus.TabIndex = 141
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.White
        Me.Label19.Location = New System.Drawing.Point(9, 123)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(77, 17)
        Me.Label19.TabIndex = 140
        Me.Label19.Text = "Jumlah Bus"
        '
        'Tharga
        '
        Me.Tharga.Location = New System.Drawing.Point(94, 97)
        Me.Tharga.Name = "Tharga"
        Me.Tharga.ReadOnly = True
        Me.Tharga.Size = New System.Drawing.Size(175, 20)
        Me.Tharga.TabIndex = 139
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.White
        Me.Label20.Location = New System.Drawing.Point(9, 97)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(45, 17)
        Me.Label20.TabIndex = 138
        Me.Label20.Text = "Harga"
        '
        'Tkelas
        '
        Me.Tkelas.Location = New System.Drawing.Point(94, 71)
        Me.Tkelas.Name = "Tkelas"
        Me.Tkelas.ReadOnly = True
        Me.Tkelas.Size = New System.Drawing.Size(175, 20)
        Me.Tkelas.TabIndex = 137
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.White
        Me.Label21.Location = New System.Drawing.Point(9, 71)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(39, 17)
        Me.Label21.TabIndex = 136
        Me.Label21.Text = "Kelas"
        '
        'Tjurusan
        '
        Me.Tjurusan.Location = New System.Drawing.Point(94, 45)
        Me.Tjurusan.Name = "Tjurusan"
        Me.Tjurusan.ReadOnly = True
        Me.Tjurusan.Size = New System.Drawing.Size(175, 20)
        Me.Tjurusan.TabIndex = 135
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.White
        Me.Label22.Location = New System.Drawing.Point(9, 45)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(55, 17)
        Me.Label22.TabIndex = 134
        Me.Label22.Text = "Jurusan"
        '
        'Tsisa
        '
        Me.Tsisa.Location = New System.Drawing.Point(704, 19)
        Me.Tsisa.Name = "Tsisa"
        Me.Tsisa.ReadOnly = True
        Me.Tsisa.Size = New System.Drawing.Size(129, 20)
        Me.Tsisa.TabIndex = 151
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.White
        Me.Label23.Location = New System.Drawing.Point(597, 19)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(31, 17)
        Me.Label23.TabIndex = 150
        Me.Label23.Text = "Sisa"
        '
        'Tdibayar
        '
        Me.Tdibayar.Location = New System.Drawing.Point(435, 19)
        Me.Tdibayar.Name = "Tdibayar"
        Me.Tdibayar.Size = New System.Drawing.Size(129, 20)
        Me.Tdibayar.TabIndex = 149
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.White
        Me.Label24.Location = New System.Drawing.Point(317, 19)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(89, 17)
        Me.Label24.TabIndex = 148
        Me.Label24.Text = "Jumlah Bayar"
        '
        'Ttotal_bayar
        '
        Me.Ttotal_bayar.Location = New System.Drawing.Point(128, 19)
        Me.Ttotal_bayar.Name = "Ttotal_bayar"
        Me.Ttotal_bayar.ReadOnly = True
        Me.Ttotal_bayar.Size = New System.Drawing.Size(129, 20)
        Me.Ttotal_bayar.TabIndex = 147
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.ForeColor = System.Drawing.Color.White
        Me.Label25.Location = New System.Drawing.Point(7, 19)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(75, 17)
        Me.Label25.TabIndex = 146
        Me.Label25.Text = "Total Bayar"
        '
        'Tno_bangku
        '
        Me.Tno_bangku.Location = New System.Drawing.Point(94, 175)
        Me.Tno_bangku.Name = "Tno_bangku"
        Me.Tno_bangku.Size = New System.Drawing.Size(175, 20)
        Me.Tno_bangku.TabIndex = 145
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.ForeColor = System.Drawing.Color.White
        Me.Label26.Location = New System.Drawing.Point(9, 175)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(79, 17)
        Me.Label26.TabIndex = 144
        Me.Label26.Text = "No. Bangku"
        '
        'Tnm_pembeli
        '
        Me.Tnm_pembeli.Location = New System.Drawing.Point(128, 19)
        Me.Tnm_pembeli.Name = "Tnm_pembeli"
        Me.Tnm_pembeli.Size = New System.Drawing.Size(161, 20)
        Me.Tnm_pembeli.TabIndex = 153
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.ForeColor = System.Drawing.Color.White
        Me.Label27.Location = New System.Drawing.Point(11, 19)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(96, 17)
        Me.Label27.TabIndex = 152
        Me.Label27.Text = "Nama Pembeli"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Tjam_berangkat)
        Me.GroupBox1.Controls.Add(Me.Ttelpon)
        Me.GroupBox1.Controls.Add(Me.Tnm_pembeli)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label27)
        Me.GroupBox1.Controls.Add(Me.Ttgl_berangkat)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.Ttgl_transaksi)
        Me.GroupBox1.Controls.Add(Me.Label16)
        Me.GroupBox1.ForeColor = System.Drawing.Color.White
        Me.GroupBox1.Location = New System.Drawing.Point(12, 92)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(302, 211)
        Me.GroupBox1.TabIndex = 154
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Data Penumpang"
        '
        'Tjam_berangkat
        '
        Me.Tjam_berangkat.CustomFormat = "H:m"
        Me.Tjam_berangkat.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Tjam_berangkat.Location = New System.Drawing.Point(129, 125)
        Me.Tjam_berangkat.Name = "Tjam_berangkat"
        Me.Tjam_berangkat.Size = New System.Drawing.Size(161, 20)
        Me.Tjam_berangkat.TabIndex = 154
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Twarna)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Tno_polisi)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Tjenis)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.Tmerk)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.Tbahan_bakar)
        Me.GroupBox2.Controls.Add(Me.Ckode_mobil)
        Me.GroupBox2.ForeColor = System.Drawing.Color.White
        Me.GroupBox2.Location = New System.Drawing.Point(601, 92)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(265, 210)
        Me.GroupBox2.TabIndex = 155
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Data Mobil"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Ckode_tiket)
        Me.GroupBox3.Controls.Add(Me.Label17)
        Me.GroupBox3.Controls.Add(Me.Label22)
        Me.GroupBox3.Controls.Add(Me.Tjurusan)
        Me.GroupBox3.Controls.Add(Me.Label21)
        Me.GroupBox3.Controls.Add(Me.Tkelas)
        Me.GroupBox3.Controls.Add(Me.Label20)
        Me.GroupBox3.Controls.Add(Me.Tharga)
        Me.GroupBox3.Controls.Add(Me.Label19)
        Me.GroupBox3.Controls.Add(Me.Tjumlah_beli)
        Me.GroupBox3.Controls.Add(Me.Tno_bangku)
        Me.GroupBox3.Controls.Add(Me.Label18)
        Me.GroupBox3.Controls.Add(Me.Label26)
        Me.GroupBox3.Controls.Add(Me.Tjumlah_bus)
        Me.GroupBox3.ForeColor = System.Drawing.Color.White
        Me.GroupBox3.Location = New System.Drawing.Point(320, 92)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(275, 211)
        Me.GroupBox3.TabIndex = 125
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Data Tiket"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Label25)
        Me.GroupBox4.Controls.Add(Me.Ttotal_bayar)
        Me.GroupBox4.Controls.Add(Me.Label24)
        Me.GroupBox4.Controls.Add(Me.Tdibayar)
        Me.GroupBox4.Controls.Add(Me.Tsisa)
        Me.GroupBox4.Controls.Add(Me.Label23)
        Me.GroupBox4.ForeColor = System.Drawing.Color.White
        Me.GroupBox4.Location = New System.Drawing.Point(12, 308)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(854, 57)
        Me.GroupBox4.TabIndex = 125
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Pembayaran"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.RoyalBlue
        Me.Button1.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button1.Location = New System.Drawing.Point(761, 573)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(105, 27)
        Me.Button1.TabIndex = 156
        Me.Button1.Text = "Cetak Tiket"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'FPemesanan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SteelBlue
        Me.ClientSize = New System.Drawing.Size(881, 606)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Tcari)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.DGpemesanan)
        Me.Controls.Add(Me.Btutup)
        Me.Controls.Add(Me.Bbatal)
        Me.Controls.Add(Me.Bsimpan)
        Me.Controls.Add(Me.Tnama_kasir)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Tkode_pemesanan)
        Me.Controls.Add(Me.Label4)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FPemesanan"
        Me.Text = "Pemesanan"
        CType(Me.DGpemesanan, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Tjenis As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Ttelpon As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Tno_polisi As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Tcari As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents DGpemesanan As DataGridView
    Friend WithEvents Btutup As Button
    Friend WithEvents Bbatal As Button
    Friend WithEvents Bsimpan As Button
    Friend WithEvents Tnama_kasir As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Tkode_pemesanan As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Tbahan_bakar As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Twarna As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Tmerk As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents Ckode_mobil As ComboBox
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Ttgl_transaksi As DateTimePicker
    Friend WithEvents Ttgl_berangkat As DateTimePicker
    Friend WithEvents Ckode_tiket As ComboBox
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Tjumlah_beli As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents Tjumlah_bus As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Tharga As TextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents Tkelas As TextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents Tjurusan As TextBox
    Friend WithEvents Label22 As Label
    Friend WithEvents Tsisa As TextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents Tdibayar As TextBox
    Friend WithEvents Label24 As Label
    Friend WithEvents Ttotal_bayar As TextBox
    Friend WithEvents Label25 As Label
    Friend WithEvents Tno_bangku As TextBox
    Friend WithEvents Label26 As Label
    Friend WithEvents Tnm_pembeli As TextBox
    Friend WithEvents Label27 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents Tjam_berangkat As DateTimePicker
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
