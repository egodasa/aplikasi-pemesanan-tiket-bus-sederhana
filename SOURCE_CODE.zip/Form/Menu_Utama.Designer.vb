﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FMenu_Utama
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FMenu_Utama))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Bbus = New System.Windows.Forms.Button()
        Me.Btiket = New System.Windows.Forms.Button()
        Me.Bpemesanan = New System.Windows.Forms.Button()
        Me.Blaporan_pemesanan = New System.Windows.Forms.Button()
        Me.Blaporan_tiket = New System.Windows.Forms.Button()
        Me.Blaporan_mobil = New System.Windows.Forms.Button()
        Me.Bkeluar = New System.Windows.Forms.Button()
        Me.Bpengguna = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 21.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(299, 35)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "PO. JASA MALINDO"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Bbus
        '
        Me.Bbus.BackColor = System.Drawing.Color.White
        Me.Bbus.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Bbus.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bbus.Image = CType(resources.GetObject("Bbus.Image"), System.Drawing.Image)
        Me.Bbus.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Bbus.Location = New System.Drawing.Point(18, 77)
        Me.Bbus.Name = "Bbus"
        Me.Bbus.Size = New System.Drawing.Size(254, 58)
        Me.Bbus.TabIndex = 20
        Me.Bbus.Text = "Data Mobil"
        Me.Bbus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Bbus.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Bbus.UseVisualStyleBackColor = False
        '
        'Btiket
        '
        Me.Btiket.BackColor = System.Drawing.Color.White
        Me.Btiket.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btiket.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btiket.Image = CType(resources.GetObject("Btiket.Image"), System.Drawing.Image)
        Me.Btiket.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Btiket.Location = New System.Drawing.Point(18, 141)
        Me.Btiket.Name = "Btiket"
        Me.Btiket.Size = New System.Drawing.Size(254, 58)
        Me.Btiket.TabIndex = 21
        Me.Btiket.Text = "Data Tiket"
        Me.Btiket.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Btiket.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Btiket.UseVisualStyleBackColor = False
        '
        'Bpemesanan
        '
        Me.Bpemesanan.BackColor = System.Drawing.Color.White
        Me.Bpemesanan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Bpemesanan.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bpemesanan.Image = CType(resources.GetObject("Bpemesanan.Image"), System.Drawing.Image)
        Me.Bpemesanan.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Bpemesanan.Location = New System.Drawing.Point(18, 205)
        Me.Bpemesanan.Name = "Bpemesanan"
        Me.Bpemesanan.Size = New System.Drawing.Size(254, 58)
        Me.Bpemesanan.TabIndex = 22
        Me.Bpemesanan.Text = "Data Pemesanan"
        Me.Bpemesanan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Bpemesanan.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Bpemesanan.UseVisualStyleBackColor = False
        '
        'Blaporan_pemesanan
        '
        Me.Blaporan_pemesanan.BackColor = System.Drawing.Color.White
        Me.Blaporan_pemesanan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Blaporan_pemesanan.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Blaporan_pemesanan.Image = CType(resources.GetObject("Blaporan_pemesanan.Image"), System.Drawing.Image)
        Me.Blaporan_pemesanan.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Blaporan_pemesanan.Location = New System.Drawing.Point(299, 205)
        Me.Blaporan_pemesanan.Name = "Blaporan_pemesanan"
        Me.Blaporan_pemesanan.Size = New System.Drawing.Size(290, 58)
        Me.Blaporan_pemesanan.TabIndex = 25
        Me.Blaporan_pemesanan.Text = "Laporan Pemesanan"
        Me.Blaporan_pemesanan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Blaporan_pemesanan.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Blaporan_pemesanan.UseVisualStyleBackColor = False
        '
        'Blaporan_tiket
        '
        Me.Blaporan_tiket.BackColor = System.Drawing.Color.White
        Me.Blaporan_tiket.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Blaporan_tiket.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Blaporan_tiket.Image = CType(resources.GetObject("Blaporan_tiket.Image"), System.Drawing.Image)
        Me.Blaporan_tiket.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Blaporan_tiket.Location = New System.Drawing.Point(299, 141)
        Me.Blaporan_tiket.Name = "Blaporan_tiket"
        Me.Blaporan_tiket.Size = New System.Drawing.Size(290, 58)
        Me.Blaporan_tiket.TabIndex = 24
        Me.Blaporan_tiket.Text = "Laporan Tiket"
        Me.Blaporan_tiket.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Blaporan_tiket.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Blaporan_tiket.UseVisualStyleBackColor = False
        '
        'Blaporan_mobil
        '
        Me.Blaporan_mobil.BackColor = System.Drawing.Color.White
        Me.Blaporan_mobil.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Blaporan_mobil.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Blaporan_mobil.Image = CType(resources.GetObject("Blaporan_mobil.Image"), System.Drawing.Image)
        Me.Blaporan_mobil.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Blaporan_mobil.Location = New System.Drawing.Point(299, 77)
        Me.Blaporan_mobil.Name = "Blaporan_mobil"
        Me.Blaporan_mobil.Size = New System.Drawing.Size(290, 58)
        Me.Blaporan_mobil.TabIndex = 23
        Me.Blaporan_mobil.Text = "Laporan Mobil"
        Me.Blaporan_mobil.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Blaporan_mobil.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Blaporan_mobil.UseVisualStyleBackColor = False
        '
        'Bkeluar
        '
        Me.Bkeluar.BackColor = System.Drawing.Color.White
        Me.Bkeluar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Bkeluar.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bkeluar.Image = CType(resources.GetObject("Bkeluar.Image"), System.Drawing.Image)
        Me.Bkeluar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Bkeluar.Location = New System.Drawing.Point(299, 269)
        Me.Bkeluar.Name = "Bkeluar"
        Me.Bkeluar.Size = New System.Drawing.Size(290, 58)
        Me.Bkeluar.TabIndex = 26
        Me.Bkeluar.Text = "Keluar"
        Me.Bkeluar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Bkeluar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Bkeluar.UseVisualStyleBackColor = False
        '
        'Bpengguna
        '
        Me.Bpengguna.BackColor = System.Drawing.Color.White
        Me.Bpengguna.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Bpengguna.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bpengguna.Image = CType(resources.GetObject("Bpengguna.Image"), System.Drawing.Image)
        Me.Bpengguna.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Bpengguna.Location = New System.Drawing.Point(18, 269)
        Me.Bpengguna.Name = "Bpengguna"
        Me.Bpengguna.Size = New System.Drawing.Size(254, 58)
        Me.Bpengguna.TabIndex = 27
        Me.Bpengguna.Text = "Data Pengguna"
        Me.Bpengguna.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Bpengguna.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Bpengguna.UseVisualStyleBackColor = False
        '
        'FMenu_Utama
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SteelBlue
        Me.ClientSize = New System.Drawing.Size(620, 346)
        Me.Controls.Add(Me.Bpengguna)
        Me.Controls.Add(Me.Bkeluar)
        Me.Controls.Add(Me.Blaporan_pemesanan)
        Me.Controls.Add(Me.Blaporan_tiket)
        Me.Controls.Add(Me.Blaporan_mobil)
        Me.Controls.Add(Me.Bpemesanan)
        Me.Controls.Add(Me.Btiket)
        Me.Controls.Add(Me.Bbus)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FMenu_Utama"
        Me.Text = "Menu"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Bbus As Button
    Friend WithEvents Btiket As Button
    Friend WithEvents Bpemesanan As Button
    Friend WithEvents Blaporan_pemesanan As Button
    Friend WithEvents Blaporan_tiket As Button
    Friend WithEvents Blaporan_mobil As Button
    Friend WithEvents Bkeluar As Button
    Friend WithEvents Bpengguna As Button
End Class
